﻿using System.Net.Sockets;
using System.Text.Json;

namespace TcpClientApp
{
    class Program
    {
        public class Request
        {
            public string method { get; set; }
            public int Tal1 { get; set; }
            public int Tal2 { get; set; }
        }

        public class Response
        {
            public bool success { get; set; }
            public int? result { get; set; }
            public string error { get; set; }
        }

        static void Main(string[] args)
        {
            StartClient();
        }

        public static void StartClient()
        {
            Console.WriteLine("TCP Client");


            TcpClient client = new TcpClient("127.0.0.1", 12345);
            NetworkStream ns = client.GetStream();
            StreamReader reader = new StreamReader(ns);
            StreamWriter writer = new StreamWriter(ns) { AutoFlush = true };

            while (true)
            {
                Console.WriteLine("Choose one of the following actions: Random, Add, Subtract. Or write cancel to stop");
                string method = Console.ReadLine().ToLower();


                if (method == "cancel")
                {

                    Request cancelRequest = new Request { method = "cancel", Tal1 = 0, Tal2 = 0 };
                    string cancelJsonRequest = JsonSerializer.Serialize(cancelRequest);
                    writer.WriteLine(cancelJsonRequest);
                    break;
                }


                if (method != "random" && method != "add" && method != "subtract")
                {
                    Console.WriteLine("Invalid method. Please try again.");
                    continue;
                }

                Console.WriteLine("Type your first number: ");
                string firstInput = Console.ReadLine();
                if (!int.TryParse(firstInput, out int tal1))
                {
                    Console.WriteLine("Needs to be a valid number.");
                    continue;
                }

                Console.WriteLine("Type your second number: ");
                string secondInput = Console.ReadLine();
                if (!int.TryParse(secondInput, out int tal2))
                {
                    Console.WriteLine("Needs to be a valid number.");
                    continue;
                }


                Request request = new Request { method = method.ToUpper(), Tal1 = tal1, Tal2 = tal2 };
                string jsonRequest = JsonSerializer.Serialize(request);
                writer.WriteLine(jsonRequest);


                string jsonResponse = reader.ReadLine();
                Console.WriteLine("Server: " + jsonResponse);

                Response response = JsonSerializer.Deserialize<Response>(jsonResponse);
                if (response.success)
                {
                    Console.WriteLine("Result: " + response.result);
                }
                else
                {
                    Console.WriteLine("Error: " + response.error);
                }
            }

            client.Close();
            Console.WriteLine("Client disconnected");
        }
    }
}
